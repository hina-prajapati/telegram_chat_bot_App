<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Gallery;
use App\Models\TelegramUser;
use Illuminate\Http\Request;
use App\Models\TelegramMessage;
use App\Models\TelegramUserState;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Symfony\Component\HttpKernel\Profiler\Profile;

class TelegramController extends Controller
{

    public function handled(Request $request)
    {
        $update = $request->all();

        if (isset($update['callback_query'])) {
            $callbackData = $update['callback_query']['data'];
            $chatId = $update['callback_query']['message']['chat']['id'];
            $user = TelegramUser::where('telegram_user_id', $chatId)->first();
    
            if ($callbackData === 'next_match') {
                return $this->handleNextMatch($chatId, $user);
            }
        }
        // Log::info('Full Telegram update', $update);
        $data = $request->all();
        $message = $data['message'] ?? null;
        if (!$message) return response('ok');

        $chatId = $message['chat']['id'];
        $text = $message['text'] ?? '';
        $from = $message['from'];

        // Step 1: Save user
        $user = $this->saveOrUpdateUser($from);

        // Step 2: Save message
        $this->saveUserMessage($user->id, $text);

        // Step 3: Get or initialize state
        $state = TelegramUserState::firstOrCreate(
            ['telegram_user_id' => $user->id],
            ['current_step' => null, 'answers' => []]
        );

        // Step 4: Check if user already completed all steps
        $answers = $state->answers ?? [];

        if ($text === '/start') {
            // If all details already provided, show profile
            if (isset($answers['name'], $answers['email'], $answers['marital_status'])) {
                return $this->showProfile($chatId, $answers);
                // Reset offset only if not already present
                $offsetKey = "match_offset_user_" . $user->id;
                if (!cache()->has($offsetKey)) {
                    cache()->put($offsetKey, 0, now()->addMinutes(30));
                }

                // Show first matching profile after user profile
                return $this->handleNextMatch($chatId, $user);
            }

            // Else start fresh
            $state->update(['current_step' => 'awaiting_name', 'answers' => []]);
            // return $this->sendMessage(
            //     $chatId,
            //     "📱 Please enter your *10-digit* mobile number starting with 6–9:",
            //     ['parse_mode' => 'Markdown']
            // );
            return $this->sendMessage(
                $chatId,
                "💖 *Welcome to LoveConnect!* 💖\n\n" .
                    "We're excited to be part of your beautiful journey together. Let's start by knowing a bit about you!\n\n" .
                    "👉 *What's your name?*",
                ['parse_mode' => 'Markdown']
            );
            // return $this->sendMessage($chatId, "Welcome! What's your name?");
        }

        // Name
        if ($state->current_step === 'awaiting_name') {
            $answers['name'] = $text;
            $user->update(['name' => $text]);

            $state->update(['answers' => $answers, 'current_step' => 'awaiting_email']);
            return $this->sendMessage($chatId, "Nice to meet you, {$text}! What's your email?");
        }

        // Email
        if ($state->current_step === 'awaiting_email') {
            $answers['email'] = $text;
            $state->update(['answers' => $answers, 'current_step' => 'awaiting_marital_status']);

            return $this->sendMessage(
                $chatId,
                "Please select your marital status:",
                [
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Single']],
                            [['text' => 'Married']],
                            [['text' => 'Divorced']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // Marital Status
        if ($state->current_step === 'awaiting_marital_status') {
            $answers['marital_status'] = $text;
            $user->update(['marital_status' => $text]);
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_dob'
            ]);

            return $this->sendMessage(
                $chatId,
                "📅 Please enter your *Date of Birth* in `DD-MM-YYYY` format:",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'force_reply' => true,
                        'input_field_placeholder' => 'DD-MM-YYYY'
                    ])
                ]
            );
        }


        // Date of Birth
        if ($state->current_step === 'awaiting_dob') {
            try {
                // Convert 'DD-MM-YYYY' to 'YYYY-MM-DD'
                $dobFormatted = Carbon::createFromFormat('d-m-Y', $text)->format('Y-m-d');
            } catch (\Exception $e) {
                return $this->sendMessage(
                    $chatId,
                    "❌ Invalid date format. Please enter in `DD-MM-YYYY` format, e.g., *13-07-1998*.",
                    [
                        'parse_mode' => 'Markdown',
                        'reply_markup' => json_encode([
                            'force_reply' => true,
                            'input_field_placeholder' => 'DD-MM-YYYY'
                        ])
                    ]
                );
            }

            $answers = $state->answers;
            $answers['dob'] = $dobFormatted;

            // Optional: Save DOB to user table here if you want
            $user->update(['dob' => $dobFormatted]);

            $state->update(['answers' => $answers, 'current_step' => 'awaiting_state']);

            return $this->sendMessage(
                $chatId,
                "🏞️ Please select your *State*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Andhra Pradesh'], ['text' => 'Arunachal Pradesh']],
                            [['text' => 'Assam'], ['text' => 'Bihar']],
                            [['text' => 'Chhattisgarh'], ['text' => 'Goa']],
                            [['text' => 'Gujarat'], ['text' => 'Haryana']],
                            [['text' => 'Himachal Pradesh'], ['text' => 'Jharkhand']],
                            [['text' => 'Karnataka'], ['text' => 'Kerala']],
                            [['text' => 'Madhya Pradesh'], ['text' => 'Maharashtra']],
                            [['text' => 'Manipur'], ['text' => 'Meghalaya']],
                            [['text' => 'Mizoram'], ['text' => 'Nagaland']],
                            [['text' => 'Odisha'], ['text' => 'Punjab']],
                            [['text' => 'Rajasthan'], ['text' => 'Sikkim']],
                            [['text' => 'Tamil Nadu'], ['text' => 'Telangana']],
                            [['text' => 'Tripura'], ['text' => 'Uttar Pradesh']],
                            [['text' => 'Uttarakhand'], ['text' => 'West Bengal']],
                            [['text' => 'Other']]
                        ],

                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // State
        if ($state->current_step === 'awaiting_state') {
            $answers = $state->answers;
            $answers['state'] = $text;

            $state->update(['answers' => $answers, 'current_step' => 'awaiting_city']);

            $cities = match ($text) {
                'Maharashtra' => [['text' => 'Mumbai'], ['text' => 'Pune'], ['text' => 'Nagpur']],
                'Gujarat' => [['text' => 'Ahmedabad'], ['text' => 'Surat'], ['text' => 'Vadodara']],
                'Delhi' => [['text' => 'New Delhi']],
                'Rajasthan' => [['text' => 'Jaipur'], ['text' => 'Udaipur']],
                'Uttar Pradesh' => [['text' => 'Lucknow'], ['text' => 'Varanasi']],
                'Madhya Pradesh' => [['text' => 'Bhopal'], ['text' => 'Indore']],
                default => [['text' => 'Other']],
            };

            return $this->sendMessage(
                $chatId,
                "🏙️ Now select your *City*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [$cities],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // City
        if ($state->current_step === 'awaiting_city') {
            $answers = $state->answers;
            $answers['city'] = $text;

            // ✅ Update only state and city to the database
            $user->update([
                'state' => $answers['state'] ?? null,
                'city' => $answers['city']
            ]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_mother_tongue'
            ]);

            return $this->sendMessage(
                $chatId,
                "🗣️ Please select your *Mother Tongue*:",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Hindi'], ['text' => 'Marathi']],
                            [['text' => 'Gujarati'], ['text' => 'Punjabi']],
                            [['text' => 'Tamil'], ['text' => 'Telugu']],
                            [['text' => 'Kannada'], ['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // Mother Tongue
        if ($state->current_step === 'awaiting_mother_tongue') {
            $answers['mother_tongue'] = $text;

            $user->update([
                'mother_tongue' => $text
            ]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_religion'
            ]);

            return $this->sendMessage(
                $chatId,
                "🙏 Please select your *Religion*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Hindu'], ['text' => 'Muslim']],
                            [['text' => 'Christian'], ['text' => 'Sikh']],
                            [['text' => 'Buddhist'], ['text' => 'Jain']],
                            [['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // religion
        if ($state->current_step === 'awaiting_religion') {
            $answers['religion'] = $text;
            $user->update(['religion' => $text]);
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_caste'
            ]);

            $casteOptions = match (strtolower($text)) {
                'hindu' => [['text' => 'Brahmin'], ['text' => 'Maratha'], ['text' => 'Rajput'], ['text' => 'Other']],
                'muslim' => [['text' => 'Sunni'], ['text' => 'Shia'], ['text' => 'Other']],
                'christian' => [['text' => 'Catholic'], ['text' => 'Protestant'], ['text' => 'Other']],
                'sikh' => [['text' => 'Jat'], ['text' => 'Ramgarhia'], ['text' => 'Other']],
                default => [['text' => 'Other']]
            };

            return $this->sendMessage(
                $chatId,
                "🕉️ Now please select your *Caste*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [$casteOptions],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // Caste
        if ($state->current_step === 'awaiting_caste') {
            $answers['caste'] = $text;
            $user->update(['caste' => $text]);
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_education_level'
            ]);

            return $this->sendMessage(
                $chatId,
                "🎓 Please select your *Highest Education Level*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'High School'], ['text' => 'Diploma']],
                            [['text' => 'Bachelor\'s'], ['text' => 'Master\'s']],
                            [['text' => 'PhD'], ['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // Education Lavel
        if ($state->current_step === 'awaiting_education_level') {
            $answers['education_level'] = $text;
            $user->update(['education_level' => $text]);
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_education_field'
            ]);

            return $this->sendMessage(
                $chatId,
                "📚 Please select your *Field of Study*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Engineering'], ['text' => 'Arts']],
                            [['text' => 'Science'], ['text' => 'Commerce']],
                            [['text' => 'Law'], ['text' => 'Medical']],
                            [['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // Education fields
        if ($state->current_step === 'awaiting_education_field') {
            $answers['education_field'] = $text;
            $user->update(['education_field' => $text]);
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_working_sector'
            ]);

            return $this->sendMessage(
                $chatId,
                "🏢 Select your *Working Sector*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Private'], ['text' => 'Government']],
                            [['text' => 'Business'], ['text' => 'Freelancer']],
                            [['text' => 'Not Working'], ['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // Working Sector
        if ($state->current_step === 'awaiting_working_sector') {
            $answers['working_sector'] = $text;
            $user->update(['working_sector' => $text]);
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_profession'
            ]);


            return $this->sendMessage(
                $chatId,
                "💼 Please select your *Profession*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Software Engineer'], ['text' => 'Doctor']],
                            [['text' => 'Teacher'], ['text' => 'Businessman']],
                            [['text' => 'Lawyer'], ['text' => 'Designer']],
                            [['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // Profession
        if ($state->current_step === 'awaiting_profession') {
            $answers['profession'] = $text;
            $user->update(['profession' => $text]);
            $user->update([
                'education_level'   => $answers['education_level'] ?? null,
                'education_field'   => $answers['education_field'] ?? null,
                'working_sector'    => $answers['working_sector'] ?? null,
                'profession'        => $answers['profession'] ?? null,
            ]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_mobile'
            ]);

            return $this->sendMessage(
                $chatId,
                "📱 Please enter your *Mobile Number*:",
                ['parse_mode' => 'Markdown']
            );
        }

        // Phone
        if ($state->current_step === 'awaiting_mobile') {
            if (!preg_match('/^[6-9]\d{9}$/', $text)) {
                return $this->sendMessage(
                    $chatId,
                    "❌ Please enter a valid *10-digit* mobile number starting with 6–9.",
                    ['parse_mode' => 'Markdown']
                );
            }

            $answers['phone'] = $text;

            // Save phone to user
            $user->update(['phone' => $text]);

            // Update state to await photo next
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_profile_photo'
            ]);

            return $this->sendMessage(
                $chatId,
                "📸 Please send your *Profile Photo*.\nYou can click a photo or upload one from your gallery.",
                ['parse_mode' => 'Markdown']
            );
        }


        // Profile Image
        if ($state->current_step === 'awaiting_profile_photo' && isset($update['message']['photo'])) {
            $photoSizes = $update['message']['photo'];
            $fileId = end($photoSizes)['file_id'];

            $filename = $this->downloadAndSaveProfilePhoto($fileId);

            if ($filename) {
                $user->update(['profile_photo' => $filename]);

                $answers = $state->answers;
                $answers['profile_photo'] = $filename;

                $state->update([
                    'current_step' => 'awaiting_diet_preference',
                    'answers' => $answers
                ]);

                $this->sendMessage($chatId, "✅ Photo saved successfully.");

                // ✅ Show profile
                // $this->showProfile($chatId, $answers);

                // ✅ Ask next question
                return $this->sendMessage($chatId, "Answer a couple more questions honestly so we can carry out a perfect search for you.\n\nWhat is your food preference?", [
                    'reply_markup' => json_encode([
                        'keyboard' => [['Veg'], ['Non-Veg'], ['Both']],
                        'one_time_keyboard' => true,
                        'resize_keyboard' => true,
                    ]),
                ]);
            } else {
                return $this->sendMessage($chatId, "❌ Failed to save the image. Please try again.");
            }
        }


        // Diet
        if ($state->current_step === 'awaiting_diet_preference') {
            $diet = $text; // Either 'Veg' or 'Non-Veg'

            $answers = $state->answers;
            $answers['diet'] = $diet;
            $user->update(['diet' => $text]);
            $state->update([
                'current_step' => 'awaiting_smoking',
                'answers' => $answers
            ]);

            return $this->sendMessage($chatId, "Do you smoke?", [
                'reply_markup' => json_encode([
                    'keyboard' => [['Yes'], ['No']],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
        }

        // Smoking
        if ($state->current_step === 'awaiting_smoking') {
            $answers = $state->answers;
            $answers['smoking'] = $text;
            $user->update(['smoking' => $text]);
            $state->update([
                'current_step' => 'awaiting_drinking',
                'answers' => $answers
            ]);

            return $this->sendMessage($chatId, "Do you enjoy drinking?", [
                'reply_markup' => json_encode([
                    'keyboard' => [['Yes'], ['No']],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
        }

        // Drinking
        if ($state->current_step === 'awaiting_drinking') {
            $answers = $state->answers;
            $answers['drinking'] = $text;
            $user->update(['drinking' => $text]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_height' // move to next step
            ]);

            return $this->sendMessage($chatId, "Please select your height:", [
                'reply_markup' => json_encode([
                    'keyboard' => [
                        ['< 150 cm'],
                        ['150-160 cm'],
                        ['160-170 cm'],
                        ['170-180 cm'],
                        ['> 180 cm']
                    ],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
        }

        // Height
        if ($state->current_step === 'awaiting_height') {
            $answers = $state->answers;
            $answers['height'] = $text;
            $user->update(['height' => $text]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_body_type'
            ]);

            return $this->sendMessage($chatId, "What is your body type?", [
                'reply_markup' => json_encode([
                    'keyboard' => [
                        ['Slim'],
                        ['Athletic'],
                        ['Average'],
                        ['Heavy']
                    ],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
        }

        // Body Type
        if ($state->current_step === 'awaiting_body_type') {
            $answers = $state->answers;
            $answers['body_type'] = $text;
            $user->update(['body_type' => $text]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_skin_tone'
            ]);

            return $this->sendMessage($chatId, "What is your skin tone?", [
                'reply_markup' => json_encode([
                    'keyboard' => [
                        ['Fair'],
                        ['Wheatish'],
                        ['Dark']
                    ],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
        }

        // Skin Tone
        if ($state->current_step === 'awaiting_skin_tone') {
            $answers = $state->answers;
            $answers['skin_tone'] = $text;
            $user->update(['skin_tone' => $text]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_gender'
            ]);

            return $this->sendMessage($chatId, "What is your Gender?", [
                'reply_markup' => json_encode([
                    'keyboard' => [
                        ['Male'],
                        ['Female'],
                    ],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
        }

        // Life Partner
        if ($state->current_step === 'awaiting_gender') {
            $answers = $state->answers;
            $answers['gender'] = $text;
            $user->update(['gender' => $text]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_partner_marital_status'
            ]);
            $this->showProfile($chatId, $answers);
            return $this->sendMessage($chatId, "Let us know how you see your future life partner.\n\n What is your preferred partner's marital status?", [
                'reply_markup' => json_encode([
                    'keyboard' => [['Single'], ['Divorced'], ['Widowed']],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
            // ✅ All done, show profile
            // return $this->showProfile($chatId, $answers);
        }

        // Marital Status
        if ($state->current_step === 'awaiting_partner_marital_status') {
            $answers = $state->answers;
            $answers['partner_marital_status'] = $text;
            $user->update(['partner_marital_status' => $text]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_partner_caste'
            ]);

            return $this->sendMessage(
                $chatId,
                "🙏 Please select your *Preferred Partner's Caste*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Hindu'], ['text' => 'Muslim']],
                            [['text' => 'Christian'], ['text' => 'Sikh']],
                            [['text' => 'Jain'], ['text' => 'Buddhist']],
                            [['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // Partner Caste
        if ($state->current_step === 'awaiting_partner_caste') {
            $answers = $state->answers;
            $answers['partner_caste'] = $text;
            $user->update(['partner_caste' => $text]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_partner_min_age'
            ]);

            return $this->sendMessage($chatId, "What is the minimum age of your preferred partner?");
        }

        if ($state->current_step === 'awaiting_partner_min_age') {
            $answers = $state->answers;
            $answers['partner_min_age'] = $text;
            $user->update(['partner_min_age' => $text]);
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_partner_max_age'
            ]);

            return $this->sendMessage($chatId, "What is the maximum age of your preferred partner?");
        }
        if ($state->current_step === 'awaiting_partner_max_age') {
            $answers = $state->answers;
            $answers['partner_max_age'] = $text;
            $user->update(['partner_max_age' => $text]);
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_partner_min_height'
            ]);

            return $this->sendMessage($chatId, "Preferred minimum height of your partner?", [
                'reply_markup' => json_encode([
                    'keyboard' => [['< 150 cm'], ['150-160 cm'], ['160-170 cm'], ['170-180 cm'], ['> 180 cm']],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
        }
        if ($state->current_step === 'awaiting_partner_min_height') {
            $answers = $state->answers;
            $answers['partner_min_height'] = $text;
            $user->update(['partner_min_height' => $text]);
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_partner_max_height'
            ]);

            return $this->sendMessage($chatId, "Preferred maximum height of your partner?", [
                'reply_markup' => json_encode([
                    'keyboard' => [['< 150 cm'], ['150-160 cm'], ['160-170 cm'], ['170-180 cm'], ['> 180 cm']],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
        }
        if ($state->current_step === 'awaiting_partner_max_height') {
            $answers = $state->answers;
            $answers['partner_max_height'] = $text;
            $user->update(['partner_max_height' => $text]);
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_partner_gender'
            ]);

            return $this->sendMessage($chatId, "Preferred gender of your partner?", [
                'reply_markup' => json_encode([
                    'keyboard' => [['Male'], ['Female'], ['Other']],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
        }
        if ($state->current_step === 'awaiting_partner_gender') {
            $answers = $state->answers;
            $answers['partner_gender'] = $text;
            $user->update(['partner_gender' => $text]);
            $user->update($answers);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_partner_language'
            ]);
            return $this->sendMessage($chatId, "Preferred language of your partner?", [
                'reply_markup' => json_encode([
                    'keyboard' => [
                        ['Hindi'],
                        ['English'],
                        ['Gujarati'],
                        ['Marathi'],
                        ['Punjabi'],
                        ['Other'],
                    ],
                    'one_time_keyboard' => true,
                    'resize_keyboard' => true,
                ]),
            ]);
            // return $this->showProfile($chatId, $answers);
        }

        if ($state->current_step === 'awaiting_partner_language') {
            $answers = $state->answers;
            $answers['partner_language'] = $text;
            $user->update(['partner_language' => $text]);
            $user->update($answers); // ✅ Save all data to the user table

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_gallery_photo'
            ]);

            return $this->sendMessage($chatId, "🎉 Cool! Now all set. Let's upload and create your photo gallery.\n\nPlease send your first photo.");
        }

        if ($state->current_step === 'awaiting_gallery_photo' && isset($update['message']['photo'])) {
            $photoSizes = $update['message']['photo'];
            $fileId = end($photoSizes)['file_id'];

            $filename = $this->downloadAndSaveGalleryPhoto($fileId);

            if ($filename) {
                Gallery::create([
                    'telegram_user_id' => $user->id,
                    'image_path' => $filename
                ]);

                $this->sendMessage($chatId, "✅ Photo added to your gallery! Let me show Some Matching profile.");

                // Prepare matching profiles for next step
                $offsetKey = "match_offset_user_" . $user->id;
                cache()->put($offsetKey, 0, now()->addMinutes(30));

                // Add delay before showing matches (optional)
                sleep(1); // 1 second delay before showing match
                // 🛑 STOP script here after showing match
                return $this->handleNextMatch($chatId, $user);
            } else {
                return $this->sendMessage($chatId, "❌ Failed to upload. Try again.");
            }
        }



        return $this->sendMessage($chatId, "Type /start to begin.");
    }


    public function showProfile($chatId, $answers)
    {
        $user = TelegramUser::where('telegram_user_id', $chatId)->first();

        if (!$user) {
            return $this->sendMessage($chatId, "❌ User not found.");
        }
        // ✅ 1. Send photo first (if exists)
        if (!empty($answers['profile_photo'])) {
            $filename = $answers['profile_photo'];
            $photoUrl = secure_asset('uploads/profiles/' . $filename);
            Log::info('Profile photo URL: ' . $photoUrl);
            // Log::info("Sending profile photo to Telegram: " . $photoUrl);
            $this->sendPhoto($chatId, $photoUrl, "Your Profile Photo");
            // $this->sendPhoto($chatId, 'https://i.imgur.com/ExdKOOz.png', "🖼 Test Image");

        }

        // ✅ 2. Profile text
        $fields = [
            'Name' => $answers['name'] ?? 'N/A',
            'Email' => $answers['email'] ?? 'N/A',
            'Gender' => $answers['gender'] ?? 'N/A',
            'Marital Status' => $answers['marital_status'] ?? 'N/A',
            'Date of Birth' => $answers['dob'] ?? 'N/A',
            'State' => $answers['state'] ?? 'N/A',
            'City' => $answers['city'] ?? 'N/A',
            'Mother Tongue' => $answers['mother_tongue'] ?? 'N/A',
            'Relison' => $answers['religion'] ?? 'N/A',
            'Cast' => $answers['caste'] ?? 'N/A',
            'Education Lavel' => $answers['education_level'] ?? 'N/A',
            'Education Field' => $answers['education_field'] ?? 'N/A',
            'Working Sector' => $answers['working_sector'] ?? 'N/A',
            'Profession' => $answers['profession'] ?? 'N/A',
            'Phone' => $answers['phone'] ?? 'N/A',
            'Diet' => $answers['diet'] ?? 'N/A',
            'Smoking' => $answers['smoking'] ?? 'N/A',
            'Drinking' => $answers['drinking'] ?? 'N/A',
            'Height' => $answers['height'] ?? 'N/A',
            'Body Type' => $answers['body_type'] ?? 'N/A',
            'Skin Tone' => $answers['skin_tone'] ?? 'N/A',
        ];

        $profile = "*👤 Profile Details:*\n\n";
        foreach ($fields as $label => $value) {
            $profile .= "▪️ *{$label}:* {$value}\n";
        }
        // dd($profile);

        $this->sendMessage($chatId, $profile, ['parse_mode' => 'Markdown']);
        return $this->handleNextMatch($chatId, $user);
    }


    public function downloadAndSaveProfilePhoto($fileId)
    {
        $token = env('TELEGRAM_BOT_TOKEN');

        // Get File Path from Telegram
        $fileInfoUrl = "https://api.telegram.org/bot{$token}/getFile?file_id={$fileId}";
        $fileResponse = Http::get($fileInfoUrl);
        if (!$fileResponse->ok()) {
            Log::error("❌ Failed to get file info from Telegram", ['response' => $fileResponse->body()]);
            return null;
        }

        $filePath = $fileResponse->json()['result']['file_path'];
        $fileUrl = "https://api.telegram.org/file/bot{$token}/{$filePath}";

        // Download the file
        $fileContent = file_get_contents($fileUrl);
        if (!$fileContent) {
            Log::error("❌ Failed to download file from Telegram", ['url' => $fileUrl]);
            return null;
        }

        // Save to public/uploads/profiles/
        $filename = 'profile_' . time() . '_' . uniqid() . '.jpg';
        $destination = public_path('uploads/profiles'); // <- FIXED HERE

        if (!file_exists($destination)) {
            mkdir($destination, 0755, true);
        }

        file_put_contents("{$destination}/{$filename}", $fileContent);

        return $filename; // This goes into DB
    }


    private function saveOrUpdateUser($from)
    {
        return TelegramUser::updateOrCreate(
            ['telegram_user_id' => $from['id']],
            [
                'username' => $from['username'] ?? null,
                'first_name' => $from['first_name'] ?? null,
                'last_name' => $from['last_name'] ?? null,
                'language_code' => $from['language_code'] ?? null,
                'name' => $from['name'] ?? null,
            ]
        );
    }

    private function saveUserMessage($userId, $text)
    {
        TelegramMessage::create([
            'telegram_user_id' => $userId,
            'message' => $text,
            'is_bot' => false,
        ]);
    }


    public function sendMessage($chatId, $text, $options = [])
    {
        $token = env('TELEGRAM_BOT_TOKEN');
        if (!$token) {
            Log::error('❌ TELEGRAM_BOT_TOKEN is not set in .env');
            return;
        }
        if (empty($text)) {
            Log::error('❌ Tried to send empty message text');
            return;
        }
        $url = "https://api.telegram.org/bot{$token}/sendMessage";
        $payload = array_merge([
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'Markdown'
        ], $options);
        $response = Http::post($url, $payload);
        Log::info('Telegram sendMessage response', ['body' => $response->body()]);
        if (!$response->ok()) {
            Log::error('Telegram sendMessage failed', ['body' => $response->body()]);
        }
        return $response->json();
    }



    public function sendPhoto($chatId, $photoUrlOrPath, $caption = '')
    {
        // If it's a local path, use multipart
        if (file_exists(public_path('uploads/profiles/' . basename($photoUrlOrPath)))) {
            $response = Http::attach(
                'photo',
                file_get_contents(public_path('uploads/profiles/' . basename($photoUrlOrPath))),
                basename($photoUrlOrPath)
            )->post("https://api.telegram.org/bot" . env('TELEGRAM_BOT_TOKEN') . "/sendPhoto", [
                'chat_id' => $chatId,
                'caption' => $caption,
                'parse_mode' => 'Markdown',
            ]);
        } else {
            // Otherwise, fallback to URL
            $response = Http::post("https://api.telegram.org/bot" . env('TELEGRAM_BOT_TOKEN') . "/sendPhoto", [
                'chat_id' => $chatId,
                'photo' => $photoUrlOrPath,
                'caption' => $caption,
                'parse_mode' => 'Markdown',
            ]);
        }

        Log::info('sendPhoto response: ' . $response->body());
    }

    public function downloadAndSaveGalleryPhoto($fileId)
    {
        Log::info("📥 Getting file for file_id: $fileId");

        $token = env('TELEGRAM_BOT_TOKEN');

        $response = Http::get("https://api.telegram.org/bot{$token}/getFile", [
            'file_id' => $fileId,
        ]);

        if ($response->ok() && isset($response['result']['file_path'])) {
            $filePath = $response['result']['file_path'];
            Log::info("✅ File path retrieved: $filePath");

            $extension = pathinfo($filePath, PATHINFO_EXTENSION) ?: 'jpg';
            $filename = 'gallery_' . time() . '_' . uniqid() . '.' . $extension;

            $fileContent = file_get_contents("https://api.telegram.org/file/bot{$token}/{$filePath}");

            if (!$fileContent) {
                Log::error("❌ Failed to download file content from: $filePath");
                return null;
            }

            $destination = public_path('uploads/gallery/' . $filename);

            if (!file_exists(public_path('uploads/gallery'))) {
                mkdir(public_path('uploads/gallery'), 0777, true);
            }

            file_put_contents($destination, $fileContent);
            Log::info("✅ File saved to: $destination");

            return $filename;
        }

        Log::error("❌ Failed to get file path from Telegram: " . $response->body());
        return null;
    }

    // public function handleNextMatch($chatId, $user)
    // {
    //     $targetGender = $user->gender === 'Male' ? 'Female' : 'Male';

    //     $matches = TelegramUser::where('gender', $targetGender)
    //         ->where('id', '!=', $user->id)
    //         ->inRandomOrder()
    //         ->take(4)
    //         ->get();

    //     if ($matches->isEmpty()) {
    //         return $this->sendMessage($chatId, "😕 No matching profiles found.");
    //     }

    //     foreach ($matches as $match) {
    //         $caption = "👤 *{$match->first_name} {$match->last_name}*\n"
    //                  . "📱 Phone: {$match->phone}\n"
    //                  . "💍 Marital Status: {$match->marital_status}\n"
    //                  . "🏙️ City: {$match->city}\n"
    //                  . "🗣️ Mother Tongue: {$match->mother_tongue}\n"
    //                  . "👀 Looking for: {$match->partner_gender}";

    //         if ($match->profile_photo) {
    //             $this->sendPhoto(
    //                 $chatId,
    //                 asset('uploads/profiles/' . $match->profile_photo),
    //                 $caption,
    //                 [
    //                     'parse_mode' => 'Markdown'
    //                 ]
    //             );
    //         } else {
    //             $this->sendMessage($chatId, $caption, [
    //                 'parse_mode' => 'Markdown'
    //             ]);
    //         }
    //     }

    //     // Optionally add navigation button at the end
    //     return $this->sendMessage($chatId, "⏭️ Want more matches?", [
    //         'reply_markup' => json_encode([
    //             'inline_keyboard' => [
    //                 [['text' => '⏭️ Next Match', 'callback_data' => 'next_match']]
    //             ]
    //         ])
    //     ]);
    // }


    public function handleNextMatch($chatId, $user)
    {
        $targetGender = $user->gender === 'Male' ? 'Female' : 'Male';

        // Key to track pagination
        $offsetKey = "match_offset_user_" . $user->id;
        $offset = cache()->get($offsetKey, 0);

        // Get the next match (1 per request)
        $matches = TelegramUser::where('gender', $targetGender)
            ->where('id', '!=', $user->id)
            ->orderBy('id')
            ->skip($offset)
            ->take(1)
            ->get();

        // If no more matches left
        if ($matches->isEmpty()) {
            cache()->forget($offsetKey);
            return $this->sendMessage($chatId, "😕 No more matching profiles found.");
        }

        foreach ($matches as $match) {
            $caption = "👤 *{$match->first_name} {$match->last_name}*\n"
                . "📱 Phone: {$match->phone}\n"
                . "💍 Marital Status: {$match->marital_status}\n"
                . "🏙️ City: {$match->city}\n"
                . "🗣️ Mother Tongue: {$match->mother_tongue}\n"
                . "👀 Looking for: {$match->partner_gender}";

            if ($match->profile_photo) {
                $this->sendPhoto(
                    $chatId,
                    asset('uploads/profiles/' . $match->profile_photo),
                    $caption,
                    [
                        'parse_mode' => 'Markdown'
                    ]
                );
            } else {
                $this->sendMessage($chatId, $caption, [
                    'parse_mode' => 'Markdown'
                ]);
            }
        }

        // Increment offset correctly
        $newOffset = $offset + $matches->count();
        cache()->put($offsetKey, $newOffset, now()->addMinutes(30));

        // Add next match button
        return $this->sendMessage($chatId, "⏭️ Want more matches?", 
        [
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '⏭️ Next Match', 'callback_data' => 'next_match']]
                ]
            ])
        ]);
    }




    public function test()
    {
        return view('test');
    }
}
