<?php

namespace App\Http\Controllers;

use App\Models\TelegramUser;
use Illuminate\Http\Request;
use App\Models\TelegramMessage;
use App\Models\TelegramUserState;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class TelegramController extends Controller
{
    // public function handledd(Request $request)
    // {
    //     Log::info('🔁 Telegram webhook hit');

    //     $data = $request->all();
    //     Log::info('📥 Incoming JSON: ' . json_encode($data, JSON_PRETTY_PRINT));

    //     if (!isset($data['message'])) {
    //         Log::warning('⚠️ No message key found in request');
    //         return response('ok');
    //     }

    //     $message = $data['message'];
    //     $chat = $message['chat'];
    //     $text = $message['text'] ?? '';
    //     Log::info("💬 Message from chat ID {$chat['id']}: $text");

    //     // Save or find user
    //     $user = TelegramUser::updateOrCreate(
    //         ['telegram_user_id' => $chat['id']],
    //         [
    //             'username' => $chat['username'] ?? null,
    //             'first_name' => $chat['first_name'] ?? null,
    //             'last_name' => $chat['last_name'] ?? null,
    //             'language_code' => $message['from']['language_code'] ?? null,
    //         ]
    //     );
    //     Log::info('👤 User saved or updated', ['id' => $user->id]);

    //     // Save message
    //     TelegramMessage::create([
    //         'telegram_user_id' => $user->id,
    //         'message' => $text,
    //         'is_bot' => false,
    //     ]);
    //     Log::info('📝 Message saved to database');

    //     // Get or create user state
    //     $state = TelegramUserState::firstOrCreate(
    //         ['telegram_user_id' => $user->id],
    //         ['current_step' => null, 'answers' => []]
    //     );
    //     Log::info('🧠 User state loaded', ['current_step' => $state->current_step]);

    //     // Handle flow
    //     if ($text === '/start') {
    //         $state->update(['current_step' => 'awaiting_name']);
    //         Log::info('🚦 Starting flow: awaiting_name');
    //         return $this->sendMessage($chat['id'], "Welcome! What's your name?");
    //     }

    //     if ($state->current_step === 'awaiting_name') {
    //         $answers = $state->answers ?? [];
    //         $answers['name'] = $text;

    //         $state->update([
    //             'answers' => $answers,
    //             'current_step' => 'awaiting_email'
    //         ]);
    //         Log::info('📥 Name received', ['name' => $text]);

    //         return $this->sendMessage($chat['id'], "Nice to meet you, $text! What's your email?");
    //     }

    //     if ($state->current_step === 'awaiting_email') {
    //         $answers = $state->answers ?? [];
    //         $answers['email'] = $text;

    //         $state->update([
    //             'answers' => $answers,
    //             'current_step' => null
    //         ]);
    //         Log::info('📥 Email received and flow ended', $answers);

    //         return $this->sendMessage($chat['id'], "Thanks! Your name is *{$answers['name']}* and email is *{$answers['email']}*.");
    //     }

    //     Log::info('ℹ️ Default response sent');
    //     return $this->sendMessage($chat['id'], "Type /start to begin.");
    // }


    // public function handle(Request $request)
    // {
    //     Log::info('🔁 Telegram webhook hit');

    //     $data = $request->all();
    //     // Log::info('📥 Incoming JSON: ' . json_encode($data, JSON_PRETTY_PRINT));

    //     if (!isset($data['message'])) {
    //         Log::warning('⚠️ No message key found in request');
    //         return response('ok');
    //     }

    //     $message = $data['message'];
    //     $chat = $message['chat'];
    //     $text = $message['text'] ?? '';
    //     Log::info("💬 Message from chat ID {$chat['id']}: $text");

    //     // Save or find user
    //     $user = TelegramUser::updateOrCreate(
    //         ['telegram_user_id' => $chat['id']],
    //         [
    //             'username' => $chat['username'] ?? null,
    //             'first_name' => $chat['first_name'] ?? null,
    //             'last_name' => $chat['last_name'] ?? null,
    //             'language_code' => $message['from']['language_code'] ?? null,
    //         ]
    //     );
    //     Log::info('👤 User saved or updated', ['id' => $user->id]);

    //     // Save message
    //     TelegramMessage::create([
    //         'telegram_user_id' => $user->id,
    //         'message' => $text,
    //         'is_bot' => false,
    //     ]);
    //     Log::info('📝 Message saved to database');

    //     // Get or create user state
    //     $state = TelegramUserState::firstOrCreate(
    //         ['telegram_user_id' => $user->id],
    //         ['current_step' => null, 'answers' => []]
    //     );
    //     Log::info('🧠 User state loaded', ['current_step' => $state->current_step]);

    //     // FLOW HANDLING
    //     // if ($text === '/start') {
    //     //     $state->update(['current_step' => 'awaiting_name']);
    //     //     Log::info('🚦 Starting flow: awaiting_name');
    //     //     return $this->sendMessage($chat['id'], "Welcome! What's your name?");
    //     // }

    //     // if ($state->current_step === 'awaiting_name') {
    //     //     $answers = $state->answers ?? [];
    //     //     $answers['name'] = $text;

    //     //     $state->update([
    //     //         'answers' => $answers,
    //     //         'current_step' => 'awaiting_email'
    //     //     ]);
    //     //     Log::info('📥 Name received', ['name' => $text]);

    //     //     return $this->sendMessage($chat['id'], "Nice to meet you, $text! What's your email?");
    //     // }

    //     // if ($state->current_step === 'awaiting_email') {
    //     //     $answers = $state->answers ?? [];
    //     //     $answers['email'] = $text;

    //     //     $state->update([
    //     //         'answers' => $answers,
    //     //         'current_step' => 'awaiting_marital_status'
    //     //     ]);
    //     //     Log::info('📥 Email received', $answers);

    //     //     return $this->sendMessage(
    //     //         $chat['id'],
    //     //         "Please select your marital status:",
    //     //         [
    //     //             'reply_markup' => json_encode([
    //     //                 'keyboard' => [
    //     //                     [['text' => 'Single']],
    //     //                     [['text' => 'Married']],
    //     //                     [['text' => 'Divorced']]
    //     //                 ],
    //     //                 'resize_keyboard' => true,
    //     //                 'one_time_keyboard' => true
    //     //             ])
    //     //         ]
    //     //     );
    //     // }

    //     if ($text === '/start') {
    //         $state->update([
    //             'current_step' => 'awaiting_marital_status',
    //             'answers' => [
    //                 'name' => 'Test User',
    //                 'email' => 'test@example.com'
    //             ]
    //         ]);
    //         Log::info('🧪 Skipping to marital status test');

    //         return $this->sendMessage(
    //             $chat['id'],
    //             "Please select your marital status:",
    //             [
    //                 'reply_markup' => json_encode([
    //                     'keyboard' => [
    //                         [['text' => 'Single']],
    //                         [['text' => 'Married']],
    //                         [['text' => 'Divorced']]
    //                     ],
    //                     'resize_keyboard' => true,
    //                     'one_time_keyboard' => true
    //                 ])
    //             ]
    //         );
    //     }


    //     if ($state->current_step === 'awaiting_marital_status') {
    //         $answers = $state->answers ?? [];
    //         $answers['marital_status'] = $text;

    //         $state->update([
    //             'answers' => $answers,
    //             'current_step' => null
    //         ]);
    //         Log::info('📥 Marital status received and flow ended', $answers);

    //         $user->update([
    //             'first_name' => $answers['name'],
    //             'email' => $answers['email'],
    //             'marital_status' => $answers['marital_status'],
    //         ]);

    //         return $this->sendMessage(
    //             $chat['id'],
    //             "*👤 Profile Details:*\n\n" .
    //                 "▪️ *Name:* {$answers['name']}\n" .
    //                 "▪️ *Email:* {$answers['email']}\n" .
    //                 "▪️ *Marital Status:* {$answers['marital_status']}",
    //             ['parse_mode' => 'Markdown']
    //         );
    //     }

    //     Log::info('ℹ️ Default response sent');
    //     return $this->sendMessage($chat['id'], "Type /start to begin.");
    // }


    public function handlecc(Request $request)
    {
        $update = $request->all();
        // Log::info('Full Telegram update', $update);
        $data = $request->all();
        $message = $data['message'] ?? null;
        if (!$message) return response('ok');

        $chatId = $message['chat']['id'];
        $text = $message['text'] ?? '';
        $from = $message['from'];

        // Step 1: Save user
        $user = $this->saveOrUpdateUser($from);

        // Step 2: Save message
        $this->saveUserMessage($user->id, $text);

        // Step 3: Get or initialize state
        $state = TelegramUserState::firstOrCreate(
            ['telegram_user_id' => $user->id],
            ['current_step' => null, 'answers' => []]
        );

        // Step 4: Check if user already completed all steps
        $answers = $state->answers ?? [];

        if ($text === '/start') {
            // If all details already provided, show profile
            if (isset($answers['name'], $answers['email'], $answers['marital_status'])) {
                return $this->showProfile($chatId, $answers);
            }

            // Else start fresh
            $state->update(['current_step' => 'awaiting_name', 'answers' => []]);
            return $this->sendMessage(
                $chatId,
                "💖 *Welcome to LoveConnect!* 💖\n\n" .
                    "We're excited to be part of your beautiful journey together. Let's start by knowing a bit about you!\n\n" .
                    "👉 *What's your name?*",
                ['parse_mode' => 'Markdown']
            );
            // return $this->sendMessage($chatId, "Welcome! What's your name?");
        }

        // Step 5: Flow handling (modular)
        if ($state->current_step === 'awaiting_name') {
            $answers['name'] = $text;
            $state->update(['answers' => $answers, 'current_step' => 'awaiting_email']);
            return $this->sendMessage($chatId, "Nice to meet you, {$text}! What's your email?");
        }

        if ($state->current_step === 'awaiting_email') {
            $answers['email'] = $text;
            $state->update(['answers' => $answers, 'current_step' => 'awaiting_marital_status']);

            return $this->sendMessage(
                $chatId,
                "Please select your marital status:",
                [
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Single']],
                            [['text' => 'Married']],
                            [['text' => 'Divorced']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        if ($state->current_step === 'awaiting_marital_status') {
            $answers['marital_status'] = $text;

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_dob' // ✅ Set the next step properly
            ]);

            return $this->sendMessage(
                $chatId,
                "📅 Please enter your *Date of Birth* in `DD-MM-YYYY` format:",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'force_reply' => true,
                        'input_field_placeholder' => 'DD-MM-YYYY'
                    ])
                ]
            );
        }


        // Date of Birth
        if ($state->current_step === 'awaiting_dob') {
            $answers['dob'] = $text;
            // $rawDob = $text;
            // $formattedDob = null;

            // if (preg_match('/^(\d{2})-(\d{2})-(\d{4})$/', $rawDob, $matches)) {
            //     $formattedDob = "{$matches[3]}-{$matches[2]}-{$matches[1]}";
            // }

            // $answers['dob'] = $formattedDob ?? $rawDob;
            $state->update(['answers' => $answers, 'current_step' => 'awaiting_state']);

            return $this->sendMessage(
                $chatId,
                "🏞️ Please select your *State*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Maharashtra'], ['text' => 'Gujarat']],
                            [['text' => 'Rajasthan'], ['text' => 'Delhi']],
                            [['text' => 'Uttar Pradesh'], ['text' => 'Madhya Pradesh']],
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }
        // State
        if ($state->current_step === 'awaiting_state') {
            $answers['state'] = $text;
            $state->update(['answers' => $answers, 'current_step' => 'awaiting_city']);

            // show dynamic city options (example below for Maharashtra)
            $cities = match ($text) {
                'Maharashtra' => [['text' => 'Mumbai'], ['text' => 'Pune'], ['text' => 'Nagpur']],
                'Gujarat' => [['text' => 'Ahmedabad'], ['text' => 'Surat'], ['text' => 'Vadodara']],
                'Delhi' => [['text' => 'New Delhi']],
            };

            return $this->sendMessage(
                $chatId,
                "🏙️ Now select your *City*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [$cities],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        // $rawDob = $answers['dob'] ?? null;
        // $formattedDob = null;

        // if ($rawDob && preg_match('/^(\d{2})-(\d{2})-(\d{4})$/', $rawDob, $matches)) {
        //     // Convert to YYYY-MM-DD
        //     $formattedDob = "{$matches[3]}-{$matches[2]}-{$matches[1]}";
        // }

        if ($state->current_step === 'awaiting_city') {
            $answers['city'] = $text;
        // Save state and city to DB if required
        $user->update([
            'state' => $answers['state'] ?? null,
            'city' => $answers['city']
        ]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_mother_tongue'
            ]);

            return $this->sendMessage(
                $chatId,
                "🗣️ Please select your *Mother Tongue*:",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Hindi'], ['text' => 'Marathi']],
                            [['text' => 'Gujarati'], ['text' => 'Punjabi']],
                            [['text' => 'Tamil'], ['text' => 'Telugu']],
                            [['text' => 'Kannada'], ['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        if ($state->current_step === 'awaiting_mother_tongue') {
            $answers['mother_tongue'] = $text;

            $user->update([
                'mother_tongue' => $text
            ]);

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_religion'
            ]);

            return $this->sendMessage(
                $chatId,
                "🙏 Please select your *Religion*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Hindu'], ['text' => 'Muslim']],
                            [['text' => 'Christian'], ['text' => 'Sikh']],
                            [['text' => 'Buddhist'], ['text' => 'Jain']],
                            [['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        if ($state->current_step === 'awaiting_religion') {
            $answers['religion'] = $text;

            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_caste'
            ]);

            // Dynamic caste options based on religion
            $casteOptions = match (strtolower($text)) {
                'hindu' => [['text' => 'Brahmin'], ['text' => 'Maratha'], ['text' => 'Rajput'], ['text' => 'Other']],
                'muslim' => [['text' => 'Sunni'], ['text' => 'Shia'], ['text' => 'Other']],
                'christian' => [['text' => 'Catholic'], ['text' => 'Protestant'], ['text' => 'Other']],
                'sikh' => [['text' => 'Jat'], ['text' => 'Ramgarhia'], ['text' => 'Other']],
                default => [['text' => 'Other']]
            };

            return $this->sendMessage(
                $chatId,
                "🕉️ Now please select your *Caste*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [$casteOptions],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }

        if ($state->current_step === 'awaiting_caste') {
            $answers['caste'] = $text;
        
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_education_level'
            ]);
        
            return $this->sendMessage(
                $chatId,
                "🎓 Please select your *Highest Education Level*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'High School'], ['text' => 'Diploma']],
                            [['text' => 'Bachelor\'s'], ['text' => 'Master\'s']],
                            [['text' => 'PhD'], ['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }
        

        if ($state->current_step === 'awaiting_education_level') {
            $answers['education_level'] = $text;
        
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_education_field'
            ]);
        
            // return $this->sendMessage(
            //     $chatId,
            //     "📚 Please enter your *Field of Study* (e.g. Engineering, Arts, Commerce):",
            //     [
            //         'parse_mode' => 'Markdown',
            //         'reply_markup' => json_encode(['force_reply' => true])
            //     ]
            // );

            return $this->sendMessage(
                $chatId,
                "📚 Please select your *Field of Study*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Engineering'], ['text' => 'Arts']],
                            [['text' => 'Science'], ['text' => 'Commerce']],
                            [['text' => 'Law'], ['text' => 'Medical']],
                            [['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
            
        }
        if ($state->current_step === 'awaiting_education_field') {
            $answers['education_field'] = $text;
        
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_working_sector'
            ]);
        
            return $this->sendMessage(
                $chatId,
                "🏢 Select your *Working Sector*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Private'], ['text' => 'Government']],
                            [['text' => 'Business'], ['text' => 'Freelancer']],
                            [['text' => 'Not Working'], ['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
        }
        if ($state->current_step === 'awaiting_working_sector') {
            $answers['working_sector'] = $text;
        
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_profession'
            ]);
        
            // return $this->sendMessage(
            //     $chatId,
            //     "💼 Please enter your *Profession* (e.g. Software Engineer, Doctor, Teacher):",
            //     [
            //         'parse_mode' => 'Markdown',
            //         'reply_markup' => json_encode(['force_reply' => true])
            //     ]
            // );
            return $this->sendMessage(
                $chatId,
                "💼 Please select your *Profession*: ",
                [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'keyboard' => [
                            [['text' => 'Software Engineer'], ['text' => 'Doctor']],
                            [['text' => 'Teacher'], ['text' => 'Businessman']],
                            [['text' => 'Lawyer'], ['text' => 'Designer']],
                            [['text' => 'Other']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => true
                    ])
                ]
            );
            
        }
        // if ($state->current_step === 'awaiting_profession') {
        //     $answers['profession'] = $text;
        
        //     // Save to user
        //     $user->update([
        //         'education_level' => $answers['education_level'] ?? null,
        //         'education_field' => $answers['education_field'] ?? null,
        //         'working_sector' => $answers['working_sector'] ?? null,
        //         'profession' => $answers['profession'] ?? null,
        //     ]);
        
        //     $state->update([
        //         'answers' => $answers,
        //         'current_step' => null
        //     ]);
        
        //     return $this->showProfile($chatId, $answers);
        // }

        if ($state->current_step === 'awaiting_profession') {
            $answers['profession'] = $text;
        
            // Save user info
            $user->update([
                'education_level'   => $answers['education_level'] ?? null,
                'education_field'   => $answers['education_field'] ?? null,
                'working_sector'    => $answers['working_sector'] ?? null,
                'profession'        => $answers['profession'] ?? null,
            ]);
        
            $state->update([
                'answers' => $answers,
                'current_step' => 'awaiting_mobile' // 👈 next step is mobile, not photo
            ]);
        
            return $this->sendMessage(
                $chatId,
                "📱 Please enter your *Mobile Number*:",
                ['parse_mode' => 'Markdown']
            );
        }

        if ($state->current_step === 'awaiting_mobile') {
            // Basic validation (optional)
            if (!preg_match('/^[6-9]\d{9}$/', $text)) {
                return $this->sendMessage(
                    $chatId,
                    "❌ Please enter a valid *10-digit* mobile number starting with 6–9.",
                    ['parse_mode' => 'Markdown']
                );
            }
            // Save mobile number
            $answers['mobile'] = $text;
        
            $user->update([
                'mobile' => $text
            ]);

            $state->update([
            'answers' => $answers,
            'current_step' => null
            ]);
        
            return $this->showProfile($chatId, $answers);
        }
                

        return $this->sendMessage($chatId, "Type /start to begin.");
    }



    public function showProfile($chatId, $answers)
    {
        $fields = [
            'Name' => $answers['name'] ?? 'N/A',
            'Email' => $answers['email'] ?? 'N/A',
            'Marital Status' => $answers['marital_status'] ?? 'N/A',
            'Date of Birth' => $answers['dob'] ?? 'N/A',
            'State' => $answers['state'] ?? 'N/A',
            'City' => $answers['city'] ?? 'N/A',
            'Mother Tongue' => $answers['mother_tongue'] ?? 'N/A',
            'Relison' => $answers['religion'] ?? 'N/A',
            'Cast' => $answers['caste'] ?? 'N/A',

            'Education Lavel' => $answers['education_level'] ?? 'N/A',
            'Education Field' => $answers['education_field'] ?? 'N/A',
            'Working Sector' => $answers['working_sector'] ?? 'N/A',
            'Profession' => $answers['profession'] ?? 'N/A',
            'Phone' => $answers['mobile'] ?? 'N/A',

        ];

        $profile = "*👤 Profile Details:*\n\n";
        foreach ($fields as $label => $value) {
            $profile .= "▪️ *{$label}:* {$value}\n";
        }
        if (!empty($answers['profile_photo'])) {
            $photoUrl = url('uploads/profiles/' . $answers['profile_photo']);
            $this->sendPhoto($chatId, $photoUrl, "🖼 Your Profile Photo");
        }
        return $this->sendMessage($chatId, $profile, ['parse_mode' => 'Markdown']);
    }
 
    
    private function saveOrUpdateUser($from)
    {
        return TelegramUser::updateOrCreate(
            ['telegram_user_id' => $from['id']],
            [
                'username' => $from['username'] ?? null,
                'first_name' => $from['first_name'] ?? null,
                'last_name' => $from['last_name'] ?? null,
                'language_code' => $from['language_code'] ?? null,
                'name' => $from['name'] ?? null,
            ]
        );
    }

    private function saveUserMessage($userId, $text)
    {
        TelegramMessage::create([
            'telegram_user_id' => $userId,
            'message' => $text,
            'is_bot' => false,
        ]);
    }




    public function sendMessage($chatId, $text, $options = [])
    {
        $token = env('TELEGRAM_BOT_TOKEN');
        if (!$token) {
            Log::error('❌ TELEGRAM_BOT_TOKEN is not set in .env');
            return;
        }
        if (empty($text)) {
            Log::error('❌ Tried to send empty message text');
            return;
        }
        $url = "https://api.telegram.org/bot{$token}/sendMessage";
        $payload = array_merge([
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'Markdown'
        ], $options);
        $response = Http::post($url, $payload);
        Log::info('Telegram sendMessage response', ['body' => $response->body()]);
        if (!$response->ok()) {
            Log::error('Telegram sendMessage failed', ['body' => $response->body()]);
        }
        return $response->json();
    }

    public function sendPhoto($chatId, $photoUrl, $caption = '')
    {
        $token = env('TELEGRAM_BOT_TOKEN');

        $response = Http::attach(
            'photo', file_get_contents($photoUrl), basename($photoUrl)
        )->post("https://api.telegram.org/bot{$token}/sendPhoto", [
            'chat_id' => $chatId,
            'caption' => $caption
        ]);

        if (!$response->ok()) {
            Log::error('Telegram sendPhoto failed', ['body' => $response->body()]);
        }

        return $response->json();
    }

    

    public function test()
    {
        return view('test');
    }
}
