<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class BodyTypeController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['body_type'] = $text;

        $this->saveAnswer($chatId, $state, 'body_type', $text, Profile::class);

        // return [
        //     'text' => "✅ Body Type saved as *{$text}*.",
        //     'options' => ['parse_mode' => 'Markdown']
        // ];

        return [
            'text' => __('messages.body_type_saved', ['value' => $text]),
            'options' => ['parse_mode' => 'Markdown']
        ];
    }

    
    // public static function getQuestion(): string
    // {
    //     return "🏋️‍♂️ What is your *Body Type*?";
    // }

    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => 'Slim'], ['text' => 'Athletic']],
    //                 [['text' => 'Average'], ['text' => 'Heavy']]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }
    public static function getQuestion(): string
    {
        return __('messages.ask_body_type');
    }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => __('messages.body_type_slim')], ['text' => __('messages.body_type_athletic')]],
                    [['text' => __('messages.body_type_average')], ['text' => __('messages.body_type_heavy')]]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
