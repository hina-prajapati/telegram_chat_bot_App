<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class ReligionController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['religion'] = $text;

        $this->saveAnswer($chatId, $state, 'religion', $text, Profile::class);

        return [
            'text' => __('messages.thanks_religion', ['religion' => $text]),
            'options' => ['parse_mode' => 'Markdown']
        ];
    }

    // public static function getQuestion(): string
    // {
    //     return "🙏 Please select your *Religion*:";
    // }
    
    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => 'Hindu'], ['text' => 'Muslim']],
    //                 [['text' => 'Christian'], ['text' => 'Sikh']],
    //                 [['text' => 'Buddhist'], ['text' => 'Jain']],
    //                 [['text' => 'Other']]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }
    public static function getQuestion(): string
    {
        return __('messages.ask_religion');
    }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => __('messages.religion_hindu')],
                        ['text' => __('messages.religion_muslim')]
                    ],
                    [
                        ['text' => __('messages.religion_christian')],
                        ['text' => __('messages.religion_sikh')]
                    ],
                    [
                        ['text' => __('messages.religion_buddhist')],
                        ['text' => __('messages.religion_jain')]
                    ],
                    [
                        ['text' => __('messages.other')]
                    ]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
