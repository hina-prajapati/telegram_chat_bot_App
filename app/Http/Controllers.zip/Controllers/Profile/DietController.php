<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class DietController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        // Optionally, validate the input (Veg/Non-Veg/Both)
        $validOptions = ['Veg', 'Non-Veg', 'Both'];
        if (!in_array($text, $validOptions)) {
            return [
                'text' => __('messages.invalid_diet'),
                'options' => self::getOptions()
            ];
        }

        $this->saveAnswer($chatId, $state, 'diet', $text, Profile::class);

        return [
            'text' => __('messages.saved_diet', ['diet' => $text]),
            'options' => ['parse_mode' => 'Markdown']
        ];
    }

    public static function getQuestion(): string
    {
        return __('messages.ask_diet');
    }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => 'Veg'], ['text' => 'Non-Veg']],
                    [['text' => 'Both']]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}

