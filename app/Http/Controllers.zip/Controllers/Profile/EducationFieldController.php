<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class EducationFieldController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['education_field'] = $text;

        $this->saveAnswer($chatId, $state, 'education_field', $text, Profile::class);

        // return [
        //     'text' => "✅ Field of study saved as *{$text}*.",
        //     'options' => [
        //         'parse_mode' => 'Markdown'
        //     ]
        // ];
        return [
            'text' => __('messages.thanks_education_field', ['field' => $text]),
            'options' => [
                'parse_mode' => 'Markdown'
            ]
        ];
    }
    // public static function getQuestion(): string
    // {
    //     return "🔬 *Please enter your Field of Study* (e.g., Engineering, Arts, Commerce):";
    // }
    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => 'Engineering'], ['text' => 'Arts']],
    //                 [['text' => 'Commerce'], ['text' => 'Science']],
    //                 [['text' => 'Other']]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }

    public static function getQuestion(): string
    {
        return __('messages.ask_education_field');
    }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => __('messages.field_engineering')], ['text' => __('messages.field_arts')]],
                    [['text' => __('messages.field_commerce')], ['text' => __('messages.field_science')]],
                    [['text' => __('messages.other')]]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
