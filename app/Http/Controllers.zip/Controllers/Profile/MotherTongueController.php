<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class MotherTongueController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['mother_tongue'] = $text;

        $this->saveAnswer($chatId, $state, 'mother_tongue', $text, Profile::class);

        // return [
        //     'text' => "✅ Saved *{$text}*. Please wait...",
        //     'options' => [
        //         'parse_mode' => 'Markdown'
        //     ]
        // ];
        return [
            'text' => __('messages.thanks_mother_tongue', ['tongue' => $text]),
            'options' => [
                'parse_mode' => 'Markdown'
            ]
        ];
    }

    // public static function getQuestion(): string
    // {
    //     return "🗣️ *Please select your Mother Tongue:*";
    // }

    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => 'Hindi'], ['text' => 'Marathi']],
    //                 [['text' => 'Gujarati'], ['text' => 'Punjabi']],
    //                 [['text' => 'Tamil'], ['text' => 'Telugu']],
    //                 [['text' => 'Other']]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }
    public static function getQuestion(): string
    {
        return __('messages.ask_mother_tongue');
    }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => __('messages.tongue_hindi')], ['text' => __('messages.tongue_marathi')]],
                    [['text' => __('messages.tongue_gujarati')], ['text' => __('messages.tongue_punjabi')]],
                    [['text' => __('messages.tongue_tamil')], ['text' => __('messages.tongue_telugu')]],
                    [['text' => __('messages.other')]]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
