<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class EducationLevelController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['education_level'] = $text;

        $this->saveAnswer($chatId, $state, 'education_level', $text, Profile::class);

        // return [
        //     'text' => "✅ Education level saved as *{$text}*.",
        //     'options' => [
        //         'parse_mode' => 'Markdown'
        //     ]
        // ];
        return [
            'text' => __('messages.thanks_education', ['education' => $text]),
            'options' => [
                'parse_mode' => 'Markdown'
            ]
        ];
    }

    // public static function getQuestion(): string
    // {
    //     return "🎓 *Please select your Highest Education Level:*";
    // }

    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [["text" => "High School"], ["text" => "Diploma"]],
    //                 [["text" => "Bachelor's"], ["text" => "Master's"]],
    //                 [["text" => "PhD"], ["text" => "Other"]]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }
    public static function getQuestion(): string
    {
        return __('messages.ask_education');
    }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => __('messages.education_highschool')],
                        ['text' => __('messages.education_diploma')]
                    ],
                    [
                        ['text' => __('messages.education_bachelor')],
                        ['text' => __('messages.education_master')]
                    ],
                    [
                        ['text' => __('messages.education_phd')],
                        ['text' => __('messages.other')]
                    ],
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
