<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

// class CityController extends BaseQuestionController
// {
//     public function handle($chatId, $text, TelegramUserState $state)
//     {
//         $answers = $state->answers;
//         $answers['city'] = $text;

//         $this->saveAnswer($chatId, $state, 'city', $text, Profile::class);

//         return [
//             'text' => "✅ City saved as *{$text}*.",
//             'options' => ['parse_mode' => 'Markdown']
//         ];
//     }

//     public static function getQuestion(): string
//     {
//         return "🏙️ *Please select your City:*";
//     }

//     public static function getOptions(array $answers = []): array
//     {
//         $selectedState = $answers['state'] ?? null;

//         $cityList = match ($selectedState) {
         
//             'Chandigarh' => ['Chandigarh'],
//             'Ladakh' => ['Leh', 'Kargil'],
//             'Jammu and Kashmir' => ['Srinagar', 'Jammu', 'Anantnag', 'Baramulla'],
//             'Puducherry' => ['Puducherry', 'Karaikal', 'Mahe', 'Yanam'],
//             default => ['Other'],
//         };

//         // Build 2-column keyboard
//         $keyboard = array_chunk($cityList, 2);

//         return [
//             'parse_mode' => 'Markdown',
//             'reply_markup' => json_encode([
//                 'keyboard' => $keyboard,
//                 'resize_keyboard' => true,
//                 'one_time_keyboard' => true,
//             ])
//         ];
//     }
// }
use Illuminate\Support\Facades\DB;

class CityController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['city'] = $text;

        $this->saveAnswer($chatId, $state, 'city', $text, Profile::class);

        // return [
        //     'text' => "✅ City saved as *{$text}*.",
        //     'options' => ['parse_mode' => 'Markdown']
        // ];
        return [
            'text' => __('messages.thanks_city', ['city' => $text]),
            'options' => ['parse_mode' => 'Markdown']
        ];
    }

    // public static function getQuestion(): string
    // {
    //     return "🏙️ *Please select your City:*";
    // }
    public static function getQuestion(): string
    {
        return __('messages.ask_city');
    }

    public static function getOptions(array $answers = []): array
    {
        $selectedState = $answers['state'] ?? null;

        if (!$selectedState) {
            return [
                'parse_mode' => 'Markdown',
                'reply_markup' => json_encode([
                    'keyboard' => [[['text' => __('messages.select_state_first')]]],
                    'resize_keyboard' => true,
                    'one_time_keyboard' => true,
                ])
            ];
        }

        $state = DB::table('states')->where('name', $selectedState)->first();

        if (!$state) {
            return [
                'parse_mode' => 'Markdown',
                'reply_markup' => json_encode([
                    'keyboard' => [[['text' => 'Other']]], // optionally translate 'Other'
                    'resize_keyboard' => true,
                    'one_time_keyboard' => true,
                ])
            ];
        }

        $cities = DB::table('cities')
            ->where('state_id', $state->id)
            ->pluck('name')
            ->toArray();

        if (empty($cities)) {
            $cities = ['Other'];
        }

        $keyboard = array_map(
            fn($chunk) => array_map(fn($city) => ['text' => $city], $chunk),
            array_chunk($cities, 2)
        );

        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => $keyboard,
                'resize_keyboard' => true,
                'one_time_keyboard' => true,
            ])
        ];
    }

}
