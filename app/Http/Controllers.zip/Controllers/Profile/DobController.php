<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;
use Carbon\Carbon;

class DobController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        try {
            $dobFormatted = Carbon::createFromFormat('d-m-Y', $text)->format('Y-m-d');
        } catch (\Exception $e) {
            return [
                'text' => "❌ Invalid date format. Please enter in `DD-MM-YYYY` format, e.g., *13-07-1998*.",
                'options' => [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'force_reply' => true,
                        'input_field_placeholder' => 'DD-MM-YYYY'
                    ])
                ]
            ];
        }

        $answers = $state->answers;
        $answers['dob'] = $dobFormatted;

        $this->saveAnswer($chatId, $state, 'dob', $dobFormatted, Profile::class);

        // return [
        //     'text' => "✅ Date of birth saved as *" . date('d-m-Y', strtotime($dobFormatted)) . "*.",
        //     'options' => ['parse_mode' => 'Markdown']
        // ];
        return [
            'text' => __('messages.thanks_dob', ['dob' => date('d-m-Y', strtotime($dobFormatted))]),
            'options' => ['parse_mode' => 'Markdown']
        ];
    }
    // public static function getQuestion(): string
    // {
    //     return "📅 *Please enter your Date of Birth* in `DD-MM-YYYY` format:";
    // }
    public static function getQuestion(): string
    {
        return __('messages.ask_dob');
    }

    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'force_reply' => true,
    //             'input_field_placeholder' => 'DD-MM-YYYY'
    //         ])
    //     ];
    // }
    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'force_reply' => true,
                'input_field_placeholder' => __('messages.dob_placeholder')
            ])
        ];
    }
}
