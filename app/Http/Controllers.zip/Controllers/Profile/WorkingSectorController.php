<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class WorkingSectorController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['working_sector'] = $text;

        $this->saveAnswer($chatId, $state, 'working_sector', $text, Profile::class);

        // return [
        //     'text' => "✅ Working sector saved as *{$text}*.",
        //     'options' => [
        //         'parse_mode' => 'Markdown'
        //     ]
        // ];
        return [
            'text' => __('messages.thanks_working_sector', ['sector' => $text]),
            'options' => [
                'parse_mode' => 'Markdown'
            ]
        ];
    }

    // public static function getQuestion(): string
    // {
    //     return "💼 *Please select your Working Sector:*";
    // }

    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => 'Private'], ['text' => 'Government']],
    //                 [['text' => 'Business'], ['text' => 'Freelance']],
    //                 [['text' => 'Student'], ['text' => 'Not Working']]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }

    public static function getQuestion(): string
    {
        return __('messages.ask_working_sector');
    }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => __('messages.sector_private')], ['text' => __('messages.sector_government')]],
                    [['text' => __('messages.sector_business')], ['text' => __('messages.sector_freelance')]],
                    [['text' => __('messages.sector_student')], ['text' => __('messages.sector_not_working')]],
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
