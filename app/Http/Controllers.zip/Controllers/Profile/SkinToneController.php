<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class SkinToneController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['skin_tone'] = $text;

        $this->saveAnswer($chatId, $state, 'skin_tone', $text, Profile::class);

        // return [
        //     'text' => "✅ Skin Tone saved as *{$text}*.\n\nLet us know how you see your future life partner.",
        //     'options' => ['parse_mode' => 'Markdown']
        // ];
        return [
            'text' => __('messages.skin_tone_saved', ['value' => $text]) . "\n\n" . __('messages.ask_life_partner_intro'),
            'options' => ['parse_mode' => 'Markdown']
        ];
    }

    // public static function getQuestion(): string
    // {
    //     return "🧜‍♀️ Please select your *Skin Tone*:";
    // }

    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => 'Fair'], ['text' => 'Wheatish']],
    //                 [['text' => 'Dusky'], ['text' => 'Dark']]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }

    public static function getQuestion(): string
    {
        return __('messages.ask_skin_tone');
    }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => __('messages.skin_fair')], ['text' => __('messages.skin_wheatish')]],
                    [['text' => __('messages.skin_dusky')], ['text' => __('messages.skin_dark')]]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
