<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class ProfessionController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['profession'] = $text;

        $this->saveAnswer($chatId, $state, 'profession', $text, Profile::class);

        // return [
        //     'text' => "✅ Profession saved as *{$text}*.",
        //     'options' => [
        //         'parse_mode' => 'Markdown'
        //     ]
        // ];
        return [
            'text' => __('messages.thanks_profession', ['profession' => $text]),
            'options' => [
                'parse_mode' => 'Markdown'
            ]
        ];
    }
    
    // public static function getQuestion(): string
    // {
    //     return "💼 *Please enter your Profession* (e.g., Software Engineer, Doctor, Teacher):";
    // }

    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => 'Software Engineer'], ['text' => 'Doctor']],
    //                 [['text' => 'Teacher'], ['text' => 'Businessman']],
    //                 [['text' => 'Student'], ['text' => 'Other']]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }
    public static function getQuestion(): string
    {
        return __('messages.ask_profession');
    }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => __('messages.profession_software_engineer')], ['text' => __('messages.profession_doctor')]],
                    [['text' => __('messages.profession_teacher')], ['text' => __('messages.profession_businessman')]],
                    [['text' => __('messages.profession_student')], ['text' => __('messages.profession_other')]]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
