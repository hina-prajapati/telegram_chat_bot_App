<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class HeightController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        if (!is_numeric($text) || (int)$text < 100 || (int)$text > 250) {
            return [
                // 'text' => "❌ Please enter a valid height in cm (e.g., 170).",
                'text' => __('messages.height_invalid'),
                'options' => [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'force_reply' => true,
                        'input_field_placeholder' => 'e.g., 170'
                    ])
                ]
            ];
        }

        $answers = $state->answers;
        $answers['height'] = (int)$text;

        $this->saveAnswer($chatId, $state, 'height', $text, Profile::class);

        // return [
        //     'text' => "✅ Height saved as *{$text}*.",
        //     'options' => ['parse_mode' => 'Markdown']
        // ];
        return [
            'text' => __('messages.height_saved', ['value' => $text]),
            'options' => ['parse_mode' => 'Markdown']
        ];

    }
    
    // public static function getQuestion(): string
    // {
    //     return "📏 What is your *Height* in cm (e.g., 170)?";
    // }

    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'force_reply' => true,
    //             'input_field_placeholder' => 'e.g., 170'
    //         ])
    //     ];
    // }

    public static function getQuestion(): string
    {
        return __('messages.ask_height');
    }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'force_reply' => true,
                'input_field_placeholder' => 'e.g., 170'
            ])
        ];
    }
}
