<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class MaritalStatusController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['marital_status'] = $text;

        $this->saveAnswer($chatId, $state, 'marital_status', $text, Profile::class);

        // return [
        //     'text' => "✅ Marital status saved as *{$text}*.",
        //     'options' => ['parse_mode' => 'Markdown']
        // ];
        return [
            'text' => __('messages.thanks_marital_status', ['status' => $text]),
            'options' => ['parse_mode' => 'Markdown']
        ];
    }

    // public static function getQuestion(): string
    // {
    //     return "💍 *Please select your marital status:*";
    // }
    public static function getQuestion(): string
    {
        return __('messages.ask_marital_status');
    }

    // public static function getOptions(): array
    // {
    //     return [
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => 'Single']],
    //                 [['text' => 'Married']],
    //                 [['text' => 'Divorced']],
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ]),
    //         'parse_mode' => 'Markdown'
    //     ];
    // }

    public static function getOptions(): array
    {
        return [
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => __('messages.status_single')]],
                    [['text' => __('messages.status_married')]],
                    [['text' => __('messages.status_divorced')]],
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ]),
            'parse_mode' => 'Markdown'
        ];
    }
}
