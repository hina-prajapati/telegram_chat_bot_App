<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Profile;

class GenderController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['gender'] = $text;

        $this->saveAnswer($chatId, $state, 'gender', $text, Profile::class);

        // return [
        //     'text' => "✅ Gender saved as *{$text}*.",
        //     'options' => ['parse_mode' => 'Markdown']
        // ];
        return [
            'text' => __('messages.thanks_gender', ['gender' => $text]),
            'options' => ['parse_mode' => 'Markdown']
        ];
    }

    // public static function getQuestion(): string
    // {
    //     return "👩👨 Please select your *Gender*:";
    // }
    public static function getQuestion(): string
    {
        return __('messages.ask_gender');
    }

    // public static function getOptions(): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => 'Male'], ['text' => 'Female']],
    //                 [['text' => 'Other']]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }

    public static function getOptions(): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => __('messages.gender_male')], ['text' => __('messages.gender_female')]],
                    [['text' => __('messages.gender_other')]]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
