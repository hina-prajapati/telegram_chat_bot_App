<?php

namespace App\Http\Controllers\Preference;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Preference;

class PartnerCasteController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['partner_caste'] = $text;

        $this->saveAnswer($chatId, $state, 'partner_caste', $text, Preference::class);

        // return [
        //     'text' => "✅ Preferred partner caste saved as *{$text}*.",
        //     'options' => [
        //         'parse_mode' => 'Markdown'
        //     ]
        // ];

        return [
            'text' => __('messages.partner_caste_saved', ['value' => $text]),
            'options' => [
                'parse_mode' => 'Markdown'
            ]
        ];
    }

    // public static function getQuestion(): string
    // {
    //     return "🙏 Please select your *Preferred Partner's Caste*:";
    // }

    // public static function getOptions(array $answers = []): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => 'Hindu'], ['text' => 'Muslim']],
    //                 [['text' => 'Christian'], ['text' => 'Sikh']],
    //                 [['text' => 'Jain'], ['text' => 'Buddhist']],
    //                 [['text' => 'Other']]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }


    public static function getQuestion(): string
    {
        return __('messages.ask_partner_caste');
    }

    public static function getOptions(array $answers = []): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => __('messages.caste_hindu')],
                        ['text' => __('messages.caste_muslim')]
                    ],
                    [
                        ['text' => __('messages.caste_christian')],
                        ['text' => __('messages.caste_sikh')]
                    ],
                    [
                        ['text' => __('messages.caste_jain')],
                        ['text' => __('messages.caste_buddhist')]
                    ],
                    [
                        ['text' => __('messages.caste_other')]
                    ]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
