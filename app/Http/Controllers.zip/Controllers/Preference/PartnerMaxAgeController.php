<?php

namespace App\Http\Controllers\Preference;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Preference;

class PartnerMaxAgeController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        if (!is_numeric($text) || (int)$text < 18 || (int)$text > 100) {
            return [
                'text' => "❌ Please enter a valid age between 18 and 100.",
                'options' => [
                    'parse_mode' => 'Markdown',
                    'reply_markup' => json_encode([
                        'force_reply' => true,
                        'input_field_placeholder' => 'e.g., 30'
                    ])
                ]
            ];
        }
        $answers = $state->answers;
        $answers['partner_max_age'] = (int) $text;

        $this->saveAnswer($chatId, $state, 'partner_max_age', $text, Preference::class);
        return [
            'text' => "✅ Preferred *maximum age* saved as *{$text}*.",
            'options' => ['parse_mode' => 'Markdown']
        ];
    }

    public static function getQuestion(): string
    {
        return "🎂 What is your *preferred maximum age* for your partner?";
    }

    public static function getOptions(array $answers = []): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'force_reply' => true,
                'input_field_placeholder' => 'e.g., 30'
            ])
        ];
    }
}
