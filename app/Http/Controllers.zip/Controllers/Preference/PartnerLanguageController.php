<?php

namespace App\Http\Controllers\Preference;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Preference;

// class PartnerLanguageController extends BaseQuestionController
// {
//     public function handle($chatId, $text, TelegramUserState $state, )
//     {
//         $answers = $state->answers;
//         $answers['partner_language'] = $text;
//         $this->saveAnswer($chatId, $state, 'partner_language', $text, Preference::class);
    
//         // $state->update(['current_step' => null]);
//         $state->current_step = null;
//         $state->save();
//         // ✅ Show final profile
//         $telegramController = app(\App\Http\Controllers\Profile\TelegramController::class);
//         return $telegramController->showProfile($chatId, $answers);
//     }

//     // public static function getQuestion(): string
//     // {
//     //     return "🌐 What is the *preferred language* of your partner?";
//     // }

//     public static function getQuestion(): string
//     {
//         return __('messages.partner_language_question');
//     }


//     // public static function getOptions(array $answers = []): array
//     // {
//     //     return [
//     //         'parse_mode' => 'Markdown',
//     //         'reply_markup' => json_encode([
//     //             'keyboard' => [
//     //                 [['text' => 'Hindi'], ['text' => 'English']],
//     //                 [['text' => 'Gujarati'], ['text' => 'Marathi']],
//     //                 [['text' => 'Punjabi'], ['text' => 'Other']]
//     //             ],
//     //             'resize_keyboard' => true,
//     //             'one_time_keyboard' => true
//     //         ])
//     //     ];
//     // }
//     public static function getOptions(array $answers = []): array
//     {
//         return [
//             'parse_mode' => 'Markdown',
//             'reply_markup' => json_encode([
//                 'keyboard' => [
//                     [['text' => 'Hindi'], ['text' => 'English']],
//                     [['text' => 'Gujarati'], ['text' => 'Marathi']],
//                     [['text' => 'Punjabi'], ['text' => 'Other']]
//                 ],
//                 'resize_keyboard' => true,
//                 'one_time_keyboard' => true
//             ])
//         ];
//     }
// }
class PartnerLanguageController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers ?? [];
        $answers['partner_language'] = $text;

        $this->saveAnswer($chatId, $state, 'partner_language', $text, Preference::class);

        // ✅ Final step — reset current_step and show profile
        $state->answers = $answers; // Keep all answers
        $state->current_step = null;
        $state->save();

        $telegramController = app(\App\Http\Controllers\Profile\TelegramController::class);
        return $telegramController->showProfile($chatId, $answers);
    }

    public static function getQuestion(): string
    {
        return __('messages.partner_language_question');
    }

    public static function getOptions(array $answers = []): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => 'Hindi'], ['text' => 'English']],
                    [['text' => 'Gujarati'], ['text' => 'Marathi']],
                    [['text' => 'Punjabi'], ['text' => 'Other']]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
