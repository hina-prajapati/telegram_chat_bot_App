<?php

namespace App\Http\Controllers\Preference;

use App\Http\Controllers\BaseQuestionController;
use App\Http\Controllers\Controller;
use App\Models\TelegramUserState;
use App\Models\Preference;

class PartnerMaxHeightController extends BaseQuestionController
{
    public function handle($chatId, $text, TelegramUserState $state)
    {
        $answers = $state->answers;
        $answers['partner_max_height'] = $text;

        $this->saveAnswer($chatId, $state, 'partner_max_height', $text, Preference::class);

        // return [
        //     'text' => "📏 Partner maximum height saved as *{$text}*.",
        //     'options' => [
        //         'parse_mode' => 'Markdown'
        //     ]
        // ];
        return [
            'text' => __('messages.partner_max_height_saved', ['value' => $text]),
            'options' => [
                'parse_mode' => 'Markdown'
            ]
        ];
    }

    // public static function getQuestion(): string
    // {
    //     return "📏 What is your *preferred partner's maximum height*?";
    // }

    // public static function getOptions(array $answers = []): array
    // {
    //     return [
    //         'parse_mode' => 'Markdown',
    //         'reply_markup' => json_encode([
    //             'keyboard' => [
    //                 [['text' => '< 150 cm'], ['text' => '150-160 cm']],
    //                 [['text' => '160-170 cm'], ['text' => '170-180 cm']],
    //                 [['text' => '> 180 cm']]
    //             ],
    //             'resize_keyboard' => true,
    //             'one_time_keyboard' => true
    //         ])
    //     ];
    // }

    public static function getQuestion(): string
    {
        return __('messages.partner_max_height_question');
    }

    public static function getOptions(array $answers = []): array
    {
        return [
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'keyboard' => [
                    [['text' => '< 150 cm'], ['text' => '150-160 cm']],
                    [['text' => '160-170 cm'], ['text' => '170-180 cm']],
                    [['text' => '> 180 cm']]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ])
        ];
    }
}
